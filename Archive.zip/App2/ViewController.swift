//
//  ViewController.swift
//  App2
//
//  Created by Aracely Berrocal on 12/1/22.
//

import UIKit

class ViewController: UIViewController, XMLParserDelegate {

   
    
    @IBOutlet weak var apellido_textfield: UITextField!
    @IBOutlet weak var nombre_textfield: UITextField!
    
    var datos : [String] = [String]()
    let defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func guardarDatos(_ sender: Any) {
        var nombreCompleto = ""
        nombreCompleto += nombre_textfield.text!
        nombreCompleto += " "
        nombreCompleto += apellido_textfield.text!
        print(nombreCompleto)
        
        //xml
    //    let fileManager = FileManager.default
        
     //   if fileManager.fileExists(atPath: getFullPath().absoluteString)
     //   {
            let array = getData()
            datos = array
      //  }else{
      //      print("No existe el archivo")
      //  }
        
        datos.append(nombreCompleto)
        defaults.set(datos,forKey: "arrayDatos")
        print(datos)
        nombre_textfield.text = ""
        apellido_textfield.text = ""
        do{
            let datosEnJSON = try JSONSerialization.data(withJSONObject: datos)
            print(datos)
            try datosEnJSON.write(to: getFullPath())
        }catch let error{
            print(error)
        }
    }
    
    private func getDocumentPath() -> URL{
        guard let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {return URL(string: "")!}
        return path
    }
    private func getFullPath() -> URL{
        let path = getDocumentPath()
        let fileURL = path.appendingPathComponent("datos.json")
        return fileURL
    }
    private func getData() -> [String]{
        do{
            let data = try Data(contentsOf: getFullPath())
            guard let array = try JSONSerialization.jsonObject(with: data) as? [String] else {return []}
            datos = array
        }catch let error{
            print(error)
        }
        return datos
}
}
